# PeerJS Text Link

This is a text-only replacement for the original cue sender and receiver. It
contains no cue buttons, stage state, WebSocket message relay, database, or
message history.

The browser pages use PeerJS 1.5.5 and its default free PeerJS Cloud signaling
service. After signaling, text travels over an encrypted WebRTC data channel
between the endpoints. If direct NAT traversal fails, PeerJS's configured TURN
service may relay the encrypted WebRTC packets.

The Python endpoint speaks the small portion of the PeerJS protocol needed for
text data channels. It supports PeerJS's default `binary` serializer as well as
`binary-utf8`, `json`, and `raw`, so it can interoperate with the stock PeerJS
examples. It can be one end of the connection; it is not merely a web server or
a relay between two browsers.

## Browser to Python

Python 3.10 or newer is recommended.

```bash
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 python_peer.py
```

The Python process prints a random peer ID. Open `send.html` in a browser, enter
that ID, and select **Connect**. Text entered in the browser appears in the
Python terminal. Once connected, text entered in the Python terminal is sent
back to the browser.

A chosen ID can make repeated testing easier:

```bash
python3 python_peer.py --id my-python-peer
```

The ID must be unique among peers currently connected to the signaling service.
It is a locator, not proof of identity.

## Python to browser

Open `receive.html` and copy the displayed browser peer ID. Then run:

```bash
python3 python_peer.py --connect BROWSER_PEER_ID
```

The Python endpoint can also switch targets while running:

```text
/connect BROWSER_PEER_ID
```

Use `/quit` to stop it.

Outgoing Python connections use PeerJS's default `binary` format. A different
serializer can be selected for compatibility testing:

```bash
python3 python_peer.py --connect BROWSER_PEER_ID --serialization raw
```

## Browser to browser

1. Open `receive.html` on one device.
2. Copy its peer ID.
3. Open `send.html` on the other device.
4. Paste the receiver ID and connect.

Both pages can send and receive text after the data channel opens.

## Serve or publish the pages

For local testing:

```bash
python3 -m http.server 8000
```

Then open:

```text
http://127.0.0.1:8000/receive.html
http://127.0.0.1:8000/send.html
```

The browser files are static and can be published to IPFS:

- `index.html`
- `send.html`
- `receive.html`
- `messenger.js`
- `style.css`
- `vendor/peerjs.min.js`

No public Python port, domain, TLS certificate, or Python WebSocket server is
needed. Both the browser and Python make outbound connections.

## What the free service does

PeerJS Cloud brokers the WebRTC handshake. It is not the application data
server. PeerJS documents the default cloud service as free, but it has no
service guarantee. The custom `--host`, `--port`, `--path`, `--key`, and
`--insecure` Python options are included so a self-hosted PeerServer can be used
later without changing the protocol.

## Limits and security

- Messages are limited to 4,096 characters by these clients.
- PeerJS `binary`, `binary-utf8`, `json`, and `raw` connections are accepted,
  but the decoded application payload must be a text string. Files, objects,
  arbitrary binary payloads, and media are intentionally omitted.
- WebRTC encrypts the transport, but this prototype does not authenticate the
  person controlling a peer ID.
- Anyone who learns a live receiver ID can attempt to connect to it.
- No messages are persisted locally by this code.
- A restrictive network can still prevent WebRTC from connecting, especially
  if it blocks both UDP and the available TURN service.

PeerJS documentation:

- <https://peerjs.com/client/faq>
- <https://peerjs.com/server/getting-started>

The vendored PeerJS library retains its MIT license in
`vendor/PEERJS_LICENSE.txt`.
