# Third-party notice

`vendor/peerjs.min.js` is PeerJS 1.5.5, distributed under the MIT License.
Its license text is included as `vendor/PEERJS_LICENSE.txt`.

Source: <https://github.com/peers/peerjs/tree/v1.5.5>
