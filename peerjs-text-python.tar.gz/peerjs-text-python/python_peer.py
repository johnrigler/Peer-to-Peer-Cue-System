#!/usr/bin/env python3
"""PeerJS Cloud-compatible WebRTC text endpoint for Python.

This implements the PeerJS signaling and serializers needed for text data
channels. It is not a general replacement for the PeerJS JavaScript library.
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import json
import secrets
import sys
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable
from urllib.parse import quote

import aiohttp
from aiortc import (
    RTCConfiguration,
    RTCIceServer,
    RTCPeerConnection,
    RTCSessionDescription,
)
from aiortc.sdp import candidate_from_sdp
from websockets.asyncio.client import connect as websocket_connect


PEERJS_VERSION = "1.5.5"
MessageHandler = Callable[["PeerJSConnection", str], Awaitable[None] | None]
ConnectionHandler = Callable[["PeerJSConnection"], Awaitable[None] | None]
ErrorHandler = Callable[[Exception], Awaitable[None] | None]
SUPPORTED_SERIALIZATIONS = frozenset({"binary", "binary-utf8", "json", "raw"})
MAX_MESSAGE_LENGTH = 4096


def _peerjs_binary_pack_text(text: str) -> bytes:
    """Encode text with the BinaryPack string format used by PeerJS 1.5.5."""
    encoded = text.encode("utf-8")
    length = len(encoded)
    if length <= 0x0F:
        return bytes((0xB0 + length,)) + encoded
    if length <= 0xFFFF:
        return b"\xD8" + length.to_bytes(2, "big") + encoded
    if length <= 0xFFFFFFFF:
        return b"\xD9" + length.to_bytes(4, "big") + encoded
    raise ValueError("Text is too large for PeerJS binary serialization")


def _peerjs_binary_unpack_text(data: bytes) -> str:
    """Decode only BinaryPack strings, rejecting objects and binary values."""
    if not data:
        raise ValueError("PeerJS binary payload was empty")

    marker = data[0]
    if 0xB0 <= marker <= 0xBF:
        header_length = 1
        text_length = marker - 0xB0
    elif marker == 0xD8:
        header_length = 3
        if len(data) < header_length:
            raise ValueError("PeerJS binary string header was incomplete")
        text_length = int.from_bytes(data[1:3], "big")
    elif marker == 0xD9:
        header_length = 5
        if len(data) < header_length:
            raise ValueError("PeerJS binary string header was incomplete")
        text_length = int.from_bytes(data[1:5], "big")
    else:
        raise TypeError("PeerJS binary payload was not a text string")

    if len(data) != header_length + text_length:
        raise ValueError("PeerJS binary string length did not match its payload")
    return data[header_length:].decode("utf-8")


def _serialize_text(text: str, serialization: str) -> str | bytes:
    if serialization == "raw":
        return text
    if serialization == "json":
        return json.dumps(text, ensure_ascii=False, separators=(",", ":")).encode(
            "utf-8"
        )
    if serialization in {"binary", "binary-utf8"}:
        return _peerjs_binary_pack_text(text)
    raise ValueError(f"Unsupported PeerJS serialization: {serialization}")


def _deserialize_text(data: object, serialization: str) -> str:
    if serialization == "raw":
        if isinstance(data, str):
            text = data
        elif isinstance(data, (bytes, bytearray, memoryview)):
            text = bytes(data).decode("utf-8")
        else:
            raise TypeError("PeerJS raw payload was not text")
    else:
        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise TypeError(f"PeerJS {serialization} payload was not binary data")
        encoded = bytes(data)
        if serialization == "json":
            text = json.loads(encoded.decode("utf-8"))
            if not isinstance(text, str):
                raise TypeError("PeerJS JSON payload was not a text string")
        elif serialization in {"binary", "binary-utf8"}:
            text = _peerjs_binary_unpack_text(encoded)
        else:
            raise ValueError(f"Unsupported PeerJS serialization: {serialization}")

    if len(text) > MAX_MESSAGE_LENGTH:
        raise ValueError(
            f"Text messages are limited to {MAX_MESSAGE_LENGTH:,} characters"
        )
    return text


def _schedule(result: Awaitable[None] | None) -> None:
    if result is not None:
        asyncio.create_task(result)


def _normalize_path(path: str) -> str:
    return "/" + path.strip("/") + "/" if path.strip("/") else "/"


def _public_ice_configuration() -> RTCConfiguration:
    return RTCConfiguration(
        iceServers=[
            RTCIceServer(urls="stun:stun.l.google.com:19302"),
            RTCIceServer(
                urls=[
                    "turn:eu-0.turn.peerjs.com:3478",
                    "turn:us-0.turn.peerjs.com:3478",
                ],
                username="peerjs",
                credential="peerjsp",
            ),
        ]
    )


@dataclass
class PeerJSConnection:
    client: "PeerJSClient"
    remote_id: str
    connection_id: str
    peer_connection: RTCPeerConnection
    serialization: str = "raw"
    label: str = "text"
    channel: object | None = None
    open_event: asyncio.Event = field(default_factory=asyncio.Event)
    pending_candidates: list[dict] = field(default_factory=list)

    @property
    def is_open(self) -> bool:
        return bool(self.channel and self.channel.readyState == "open")

    async def wait_open(self, timeout: float = 30.0) -> None:
        await asyncio.wait_for(self.open_event.wait(), timeout)

    async def send(self, text: str) -> None:
        if not isinstance(text, str):
            raise TypeError("Only text strings are supported")
        if len(text) > MAX_MESSAGE_LENGTH:
            raise ValueError(
                f"Text messages are limited to {MAX_MESSAGE_LENGTH:,} characters"
            )
        if not self.is_open:
            raise RuntimeError("The peer data channel is not open")
        self.channel.send(_serialize_text(text, self.serialization))

    async def close(self) -> None:
        if self.channel and self.channel.readyState != "closed":
            self.channel.close()
        await self.peer_connection.close()
        self.client.connections.pop(self.connection_id, None)


class PeerJSClient:
    """A small, text-only subset of PeerJS data connections."""

    def __init__(
        self,
        peer_id: str | None = None,
        *,
        host: str = "0.peerjs.com",
        port: int = 443,
        path: str = "/",
        key: str = "peerjs",
        secure: bool = True,
        ice_configuration: RTCConfiguration | None = None,
    ) -> None:
        self.peer_id = peer_id
        self.host = host
        self.port = port
        self.path = _normalize_path(path)
        self.key = key
        self.secure = secure
        self.ice_configuration = ice_configuration or _public_ice_configuration()
        self.connections: dict[str, PeerJSConnection] = {}
        self.on_message: MessageHandler = lambda _connection, _text: None
        self.on_connection: ConnectionHandler = lambda _connection: None
        self.on_open: ConnectionHandler = lambda _connection: None
        self.on_error: ErrorHandler = lambda _error: None
        self.websocket = None
        self._opened = asyncio.Event()
        self._startup_error: Exception | None = None
        self._receive_task: asyncio.Task | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._closed = False

    @property
    def http_scheme(self) -> str:
        return "https" if self.secure else "http"

    @property
    def websocket_scheme(self) -> str:
        return "wss" if self.secure else "ws"

    async def _retrieve_id(self) -> str:
        url = (
            f"{self.http_scheme}://{self.host}:{self.port}"
            f"{self.path}{quote(self.key, safe='')}/id"
        )
        params = {"ts": f"{time.time_ns()}", "version": PEERJS_VERSION}
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                if response.status != 200:
                    raise RuntimeError(
                        f"PeerJS ID request failed: HTTP {response.status}"
                    )
                peer_id = (await response.text()).strip()
        if not peer_id:
            raise RuntimeError("PeerJS returned an empty peer ID")
        return peer_id

    def _websocket_url(self) -> str:
        token = secrets.token_urlsafe(24)
        return (
            f"{self.websocket_scheme}://{self.host}:{self.port}"
            f"{self.path}peerjs?key={quote(self.key, safe='')}"
            f"&id={quote(self.peer_id or '', safe='')}"
            f"&token={quote(token, safe='')}"
            f"&version={PEERJS_VERSION}"
        )

    async def start(self, timeout: float = 15.0) -> str:
        if self.peer_id is None:
            self.peer_id = await self._retrieve_id()
        self.websocket = await websocket_connect(
            self._websocket_url(),
            ping_interval=None,
            open_timeout=timeout,
        )
        self._receive_task = asyncio.create_task(self._receive_loop())
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        try:
            await asyncio.wait_for(self._opened.wait(), timeout)
            if self._startup_error:
                raise self._startup_error
        except Exception:
            await self.close()
            raise
        return self.peer_id

    def _report_error(self, error: Exception) -> None:
        _schedule(self.on_error(error))

    def _fail_startup(self, error: Exception) -> None:
        self._startup_error = error
        self._opened.set()

    async def _send_signal(self, message: dict) -> None:
        if self.websocket is None:
            raise RuntimeError("Not connected to the PeerJS signaling service")
        await self.websocket.send(json.dumps(message, separators=(",", ":")))

    async def _heartbeat_loop(self) -> None:
        try:
            while True:
                await asyncio.sleep(5)
                await self._send_signal({"type": "HEARTBEAT"})
        except asyncio.CancelledError:
            return
        except Exception as error:
            self._report_error(error)

    async def _receive_loop(self) -> None:
        try:
            async for raw_message in self.websocket:
                message = json.loads(raw_message)
                await self._handle_signal(message)
        except asyncio.CancelledError:
            return
        except Exception as error:
            if not self._opened.is_set():
                self._fail_startup(error)
            else:
                self._report_error(error)

    async def _handle_signal(self, message: dict) -> None:
        message_type = message.get("type")
        if message_type == "OPEN":
            self._opened.set()
            return
        if message_type in {"ERROR", "ID-TAKEN", "INVALID-KEY", "EXPIRE"}:
            error = RuntimeError(f"PeerJS signaling error: {message}")
            if not self._opened.is_set():
                self._fail_startup(error)
            else:
                self._report_error(error)
            return
        if message_type == "OFFER":
            await self._accept_offer(message)
            return
        if message_type == "LEAVE":
            remote_id = message.get("src")
            for connection in list(self.connections.values()):
                if connection.remote_id == remote_id:
                    await connection.close()
            return

        payload = message.get("payload") or {}
        connection_id = payload.get("connectionId")
        connection = self.connections.get(connection_id)
        if connection is None:
            return
        if message_type == "ANSWER":
            await connection.peer_connection.setRemoteDescription(
                RTCSessionDescription(**payload["sdp"])
            )
            await self._flush_candidates(connection)
        elif message_type == "CANDIDATE":
            await self._add_candidate(connection, payload["candidate"])

    def _configure_connection(self, connection: PeerJSConnection) -> None:
        peer_connection = connection.peer_connection

        @peer_connection.on("datachannel")
        def on_datachannel(channel) -> None:
            self._bind_channel(connection, channel)

        @peer_connection.on("connectionstatechange")
        def on_connectionstatechange() -> None:
            if peer_connection.connectionState in {"failed", "closed"}:
                self.connections.pop(connection.connection_id, None)
            if peer_connection.connectionState == "failed":
                self._report_error(
                    ConnectionError(
                        f"WebRTC connection to {connection.remote_id} failed"
                    )
                )

    def _bind_channel(self, connection: PeerJSConnection, channel) -> None:
        connection.channel = channel

        @channel.on("open")
        def on_open() -> None:
            connection.open_event.set()
            _schedule(self.on_open(connection))

        @channel.on("message")
        def on_message(data) -> None:
            try:
                text = _deserialize_text(data, connection.serialization)
            except (
                UnicodeDecodeError,
                json.JSONDecodeError,
                TypeError,
                ValueError,
            ) as error:
                self._report_error(
                    ValueError(
                        f"Ignored a non-text or invalid {connection.serialization} "
                        f"message from {connection.remote_id}: {error}"
                    )
                )
                return
            _schedule(self.on_message(connection, text))

        @channel.on("close")
        def on_close() -> None:
            self.connections.pop(connection.connection_id, None)

        if channel.readyState == "open":
            on_open()

    async def _accept_offer(self, message: dict) -> None:
        payload = message["payload"]
        if payload.get("type") != "data":
            return
        serialization = payload.get("serialization", "binary")
        if serialization not in SUPPORTED_SERIALIZATIONS:
            self._report_error(
                RuntimeError(
                    f"Rejected a connection using unsupported {serialization!r} "
                    "serialization"
                )
            )
            return
        connection_id = payload["connectionId"]
        peer_connection = RTCPeerConnection(self.ice_configuration)
        connection = PeerJSConnection(
            client=self,
            remote_id=message["src"],
            connection_id=connection_id,
            peer_connection=peer_connection,
            serialization=serialization,
            label=payload.get("label", "text"),
        )
        self.connections[connection_id] = connection
        self._configure_connection(connection)
        _schedule(self.on_connection(connection))

        await peer_connection.setRemoteDescription(
            RTCSessionDescription(**payload["sdp"])
        )
        answer = await peer_connection.createAnswer()
        await peer_connection.setLocalDescription(answer)
        local = peer_connection.localDescription
        await self._send_signal(
            {
                "type": "ANSWER",
                "payload": {
                    "sdp": {"type": local.type, "sdp": local.sdp},
                    "type": "data",
                    "connectionId": connection_id,
                },
                "dst": connection.remote_id,
            }
        )
        await self._flush_candidates(connection)

    async def connect(
        self, remote_id: str, *, serialization: str = "binary"
    ) -> PeerJSConnection:
        if serialization not in SUPPORTED_SERIALIZATIONS:
            raise ValueError(f"Unsupported PeerJS serialization: {serialization}")
        connection_id = "dc_" + secrets.token_urlsafe(18)
        peer_connection = RTCPeerConnection(self.ice_configuration)
        connection = PeerJSConnection(
            client=self,
            remote_id=remote_id,
            connection_id=connection_id,
            peer_connection=peer_connection,
            serialization=serialization,
            label=connection_id,
        )
        self.connections[connection_id] = connection
        self._configure_connection(connection)
        channel = peer_connection.createDataChannel(connection.label, ordered=True)
        self._bind_channel(connection, channel)

        offer = await peer_connection.createOffer()
        await peer_connection.setLocalDescription(offer)
        local = peer_connection.localDescription
        await self._send_signal(
            {
                "type": "OFFER",
                "payload": {
                    "sdp": {"type": local.type, "sdp": local.sdp},
                    "type": "data",
                    "connectionId": connection_id,
                    "metadata": None,
                    "label": connection.label,
                    "reliable": True,
                    "serialization": serialization,
                },
                "dst": remote_id,
            }
        )
        return connection

    async def _add_candidate(
        self, connection: PeerJSConnection, candidate_data: dict
    ) -> None:
        if connection.peer_connection.remoteDescription is None:
            connection.pending_candidates.append(candidate_data)
            return
        candidate_text = candidate_data.get("candidate", "")
        if not candidate_text:
            return
        if candidate_text.startswith("candidate:"):
            candidate_text = candidate_text[len("candidate:") :]
        candidate = candidate_from_sdp(candidate_text)
        candidate.sdpMid = candidate_data.get("sdpMid")
        candidate.sdpMLineIndex = candidate_data.get("sdpMLineIndex")
        await connection.peer_connection.addIceCandidate(candidate)

    async def _flush_candidates(self, connection: PeerJSConnection) -> None:
        pending = connection.pending_candidates
        connection.pending_candidates = []
        for candidate in pending:
            await self._add_candidate(connection, candidate)

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        for connection in list(self.connections.values()):
            await connection.close()
        for task in (self._heartbeat_task, self._receive_task):
            if task:
                task.cancel()
        if self.websocket:
            await self.websocket.close()
        for task in (self._heartbeat_task, self._receive_task):
            if task:
                with contextlib.suppress(asyncio.CancelledError):
                    await task


async def _run_cli(args: argparse.Namespace) -> None:
    client = PeerJSClient(
        args.id,
        host=args.host,
        port=args.port,
        path=args.path,
        key=args.key,
        secure=not args.insecure,
    )
    active_connection: PeerJSConnection | None = None

    def remember(connection: PeerJSConnection) -> None:
        nonlocal active_connection
        active_connection = connection
        print(f"Connected: {connection.remote_id}", flush=True)

    async def show_message(connection: PeerJSConnection, text: str) -> None:
        print(f"{connection.remote_id}: {text}", flush=True)
        if args.echo:
            await connection.send(("echo: " + text)[:4096])

    def show_error(error: Exception) -> None:
        print(f"Error: {error}", file=sys.stderr, flush=True)

    client.on_open = remember
    client.on_message = show_message
    client.on_error = show_error
    peer_id = await client.start()
    print(f"Peer ID: {peer_id}", flush=True)
    print("Type a message after a peer connects. Use /quit to stop.", flush=True)

    if args.connect:
        await client.connect(args.connect, serialization=args.serialization)

    try:
        while True:
            line = await asyncio.to_thread(sys.stdin.readline)
            if line == "":
                await asyncio.Event().wait()
            text = line.rstrip("\r\n")
            if text == "/quit":
                return
            if text.startswith("/connect "):
                active_connection = None
                await client.connect(
                    text[9:].strip(), serialization=args.serialization
                )
                continue
            if text and active_connection:
                try:
                    await active_connection.send(text)
                except (RuntimeError, TypeError, ValueError) as error:
                    show_error(error)
    finally:
        await client.close()


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="PeerJS Cloud-compatible Python text endpoint"
    )
    parser.add_argument("--id", help="Stable PeerJS ID; omit for a random ID")
    parser.add_argument("--connect", help="Connect to this peer after startup")
    parser.add_argument(
        "--serialization",
        choices=sorted(SUPPORTED_SERIALIZATIONS),
        default="binary",
        help="PeerJS serializer for outgoing connections (default: binary)",
    )
    parser.add_argument("--host", default="0.peerjs.com")
    parser.add_argument("--port", type=int, default=443)
    parser.add_argument("--path", default="/")
    parser.add_argument("--key", default="peerjs")
    parser.add_argument(
        "--insecure", action="store_true", help="Use HTTP and ws:// with a test server"
    )
    parser.add_argument("--echo", action="store_true", help="Echo received text")
    return parser.parse_args()


if __name__ == "__main__":
    try:
        asyncio.run(_run_cli(_parse_args()))
    except KeyboardInterrupt:
        pass
