(function () {
    "use strict";

    var role = document.body.dataset.role;
    if (role !== "sender" && role !== "receiver") {
        return;
    }

    var status = document.getElementById("status");
    var localId = document.getElementById("local-id");
    var connectionForm = document.getElementById("connection-form");
    var remoteIdInput = document.getElementById("remote-id");
    var connectButton = document.getElementById("connect-button");
    var copyIdButton = document.getElementById("copy-id-button");
    var messageForm = document.getElementById("message-form");
    var messageInput = document.getElementById("message-input");
    var sendButton = document.getElementById("send-button");
    var messages = document.getElementById("messages");
    var connection = null;
    var peerReady = false;

    var query = new URLSearchParams(window.location.search);
    if (remoteIdInput) {
        remoteIdInput.value = (query.get("peer") || "").trim();
    }

    // With no host configured, PeerJS uses its free public signaling service.
    var peer = new Peer(undefined, { debug: 2 });

    function setStatus(text, state) {
        status.textContent = text;
        status.className = "status" + (state ? " " + state : "");
    }

    function setChatEnabled(enabled) {
        messageInput.disabled = !enabled;
        sendButton.disabled = !enabled;
        if (enabled) {
            messageInput.focus();
        }
    }

    function setConnectEnabled(enabled) {
        if (!connectButton) {
            return;
        }
        connectButton.disabled = !enabled;
        remoteIdInput.disabled = !enabled;
    }

    function addMessage(kind, label, text) {
        var item = document.createElement("li");
        item.className = kind;

        var meta = document.createElement("span");
        meta.className = "message-meta";
        meta.textContent = label + " · " + new Date().toLocaleTimeString();

        var body = document.createElement("span");
        body.textContent = text;

        item.appendChild(meta);
        item.appendChild(body);
        messages.appendChild(item);
        messages.scrollTop = messages.scrollHeight;
    }

    function rejectConnection(incoming, reason) {
        incoming.on("open", function () {
            incoming.send(reason);
            window.setTimeout(function () {
                incoming.close();
            }, 250);
        });
    }

    function attachConnection(nextConnection) {
        connection = nextConnection;
        setChatEnabled(false);
        setConnectEnabled(false);
        setStatus("Connecting to " + nextConnection.peer + "...");

        nextConnection.on("open", function () {
            if (connection !== nextConnection) {
                nextConnection.close();
                return;
            }
            setStatus("Connected to " + nextConnection.peer + ".", "connected");
            setChatEnabled(true);
        });

        nextConnection.on("data", function (data) {
            if (typeof data !== "string") {
                addMessage("system", "System", "Ignored a non-text message.");
                return;
            }
            addMessage("peer", "Peer", data);
        });

        nextConnection.on("close", function () {
            if (connection !== nextConnection) {
                return;
            }
            connection = null;
            setChatEnabled(false);
            if (role === "receiver") {
                setStatus("Connection closed. Waiting for another peer...");
            } else {
                setStatus("Connection closed.");
                setConnectEnabled(peerReady);
            }
        });

        nextConnection.on("error", function (error) {
            setStatus("Data connection error: " + error.message, "error");
        });
    }

    peer.on("open", function (id) {
        peerReady = true;
        localId.value = id;
        if (role === "receiver") {
            setStatus("Waiting for a connection...");
        } else if (!connection) {
            setStatus("Ready. Enter the other peer's ID.");
            setConnectEnabled(true);
        }
    });

    peer.on("connection", function (incoming) {
        if (role !== "receiver") {
            rejectConnection(incoming, "This page only makes outgoing connections.");
            return;
        }
        if (connection) {
            rejectConnection(incoming, "This peer already has a connection.");
            return;
        }
        attachConnection(incoming);
    });

    peer.on("disconnected", function () {
        peerReady = false;
        if (connection && connection.open) {
            setStatus("Signaling disconnected; the current direct connection may continue.", "error");
        } else {
            setStatus("Disconnected from PeerJS Cloud. Reconnecting...", "error");
            setConnectEnabled(false);
        }
        window.setTimeout(function () {
            if (!peer.destroyed && peer.disconnected) {
                peer.reconnect();
            }
        }, 1000);
    });

    peer.on("close", function () {
        peerReady = false;
        connection = null;
        setChatEnabled(false);
        setConnectEnabled(false);
        setStatus("Peer closed. Reload the page to restart it.", "error");
    });

    peer.on("error", function (error) {
        var message = error && error.message ? error.message : String(error);
        if (error && error.type === "peer-unavailable") {
            message = "That peer ID is not currently available.";
            connection = null;
            setConnectEnabled(peerReady);
        }
        setStatus(message, "error");
    });

    if (connectionForm) {
        connectionForm.addEventListener("submit", function (event) {
            event.preventDefault();
            if (!peerReady || connection) {
                return;
            }

            var remoteId = remoteIdInput.value.trim();
            if (!remoteId) {
                setStatus("Enter a peer ID.", "error");
                return;
            }
            if (remoteId === peer.id) {
                setStatus("The remote ID must be different from this page's ID.", "error");
                return;
            }

            // PeerJS's default binary serializer is intentional here: it makes
            // this page an interoperability test for stock PeerJS clients.
            attachConnection(peer.connect(remoteId, { reliable: true }));
        });
    }

    if (copyIdButton) {
        copyIdButton.addEventListener("click", async function () {
            if (!localId.value) {
                return;
            }
            try {
                await navigator.clipboard.writeText(localId.value);
                setStatus("Peer ID copied.", "connected");
            } catch (error) {
                localId.focus();
                localId.select();
                setStatus("Select and copy the peer ID manually.");
            }
        });
    }

    messageForm.addEventListener("submit", function (event) {
        event.preventDefault();
        if (!connection || !connection.open) {
            setStatus("The data connection is not open.", "error");
            return;
        }

        var text = messageInput.value;
        if (!text.trim()) {
            return;
        }
        connection.send(text);
        addMessage("mine", "You", text);
        messageInput.value = "";
        messageInput.focus();
    });
})();
